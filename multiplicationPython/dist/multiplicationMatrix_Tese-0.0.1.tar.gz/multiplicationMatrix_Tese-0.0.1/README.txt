### Multiplication Matrix - Tese ###
Simples package onde multiplica dois vetores, tanto no GPU como no CPU

### Instalation ###
- Python
pip install multiplicationMatrix_Tese

### Usage ###
import multiplicationMatrix_Tese

#Call function
mat_file = multiplicationMatrix_Tese.read_mat("exemplo.mat")


